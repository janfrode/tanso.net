
To use this zenpack, you'll need to enable snmpd in squid.conf:

        acl snmppublic snmp_community mysecretcommunity
        snmp_port 3401
        snmp_access allow snmppublic all

and proxy these trough your hosts snmpd.conf:

        view systemview included .1.3.6.1.4.1.3495.1
        proxy -m /etc/squid/mib.txt -v 1 -c mysecretcommunity localhost:3401 .1.3.6.1.4.1.3495.1

More info, and sample graphs are available at http://tanso.net/zenoss/squid/

Feedback to janfrode@tanso.net is much appreciated !
