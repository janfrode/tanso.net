
import Globals
from Products.CMFCore.DirectoryView import registerDirectory
registerDirectory("skins", globals())
